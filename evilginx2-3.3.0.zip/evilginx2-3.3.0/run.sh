#!/bin/bash

# Chuyển vào thư mục gốc project (nếu chạy từ bất kỳ đâu)
cd "$(dirname "$0")"

# Build lại Evilginx2 (nếu cần)
echo "[*] Building Evilginx2..."
go build -o ./build/evilginx -mod=vendor

# Cấp quyền thực thi cho binary
chmod +x ./build/evilginx

# Chạy Evilginx2 với phishlets & redirectors
echo "[*] Running Evilginx2..."
sudo ./build/evilginx -p ./phishlets -t ./redirectors -developer -debug
